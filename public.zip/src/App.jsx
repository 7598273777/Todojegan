import React, { useEffect, useRef } from 'react'
import './App.css'
import Change from './Change';

function App() {
  const textRef = useRef(); // Memory
  function changeColor(e) {
    // document.getElementById('text').style.color = e.target.id;
    textRef.current.style.color = e;
  }

  useEffect(() => {
    // if(textRef) {
    //   textRef.current.style.color = "green";
    // }
  }, []);

  return (
    <>
      <h1 ref={textRef} id="text">Lets learn React Hooks</h1>
      <div>
      <button id="lightpink" onClick={changeColor}>
          Red
        </button>
        <button id="lightgreen" onClick={changeColor}>
          Green
        </button>
        <button id="lightblue" onClick={changeColor}>
          Blue
        </button>
        <Change changeColor={changeColor} />
      </div>
    </>
  )
}

export default App
