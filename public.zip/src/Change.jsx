import { useEffect } from "react"

export default function Change(props) {
    
    useEffect(() => {
        if(props.changeColor) {
            props.changeColor('red')
        }
    }, [])

    return <div>Change</div>
}